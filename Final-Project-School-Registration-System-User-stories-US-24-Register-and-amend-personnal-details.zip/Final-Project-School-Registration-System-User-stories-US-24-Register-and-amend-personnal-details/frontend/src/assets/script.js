function myFunction() { 
    document.getElementById("icon").style.display="none";  
    document.getElementById("filter").style.display="block";
    document.getElementById("sections").style.display="flex";
  }
