export const contants = {
    token: 'token',
    username: 'username',
    role: 'role'
}