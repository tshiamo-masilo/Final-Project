package testing.demo.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import testing.demo.Exception.UserNotFoundException;
import testing.demo.Repository.StudentRepo;
import testing.demo.model.Student;
import testing.demo.model.Student;

import java.util.List;
@Service
public class StudentService {
    @Autowired
    private StudentRepo studentRepo;

    public Student saveStudent(Student student){
        return studentRepo.save(student);
    }
   public Student getStudentById(int id){
        return studentRepo.findById(id).orElseThrow(()->new UserNotFoundException("User with the id :"+id+" not found"));
   }
   public List<Student> getAllStudents(){
        return studentRepo.findAll();
   }
   public String deleteStudentById(int id){
        studentRepo.deleteById(id);
        return "Record Deleted";
   }
    public String deleteAllStudent(){
        studentRepo.deleteAll();
        return "All Records are deleted";
    }
    public Student updateStudent(Student student){
        Student existingStudent=studentRepo.findById(student.getId()).orElse(null);
        existingStudent.setName(student.getName());
        existingStudent.setSurname(student.getSurname());
        existingStudent.setPhone_Number(student.getPhone_Number());
        existingStudent.setStudent_id(student.getStudent_id());
        existingStudent.setGrade(student.getGrade());
        existingStudent.setStream_id(student.getStream_id());
        existingStudent.setSchool_id(student.getSchool_id());
        existingStudent.setClass_id(student.getClass_id());
        existingStudent.setGuardian_Name(student.getGuardian_Name());
        existingStudent.setGuardian_surname(student.getGuardian_surname());
        existingStudent.setGuardian_Phone_Number(student.getGuardian_Phone_Number());
        existingStudent.setGuardian_Email_Address(student.getGuardian_Email_Address());
        existingStudent.setHome_Address(student.getHome_Address());
        return studentRepo.save(existingStudent);
    }



}
