package testing.demo.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@Table(name="Requirements_Table")
public class Requirements {
    @Id
    @GeneratedValue()
    @Column()
    private int id;
    private String StreamId;
    private String RequirementsId;
    private String Maths;
    private String Natural_Science;
    private String Technology;
    private String EMS;
    private String Arts_And_Culture;

    public Requirements() {
    }

    public Requirements(String streamId, String requirementsId, String maths, String natural_Science, String technology, String EMS, String arts_And_Culture) {
        StreamId = streamId;
        RequirementsId = requirementsId;
        Maths = maths;
        Natural_Science = natural_Science;
        Technology = technology;
        this.EMS = EMS;
        Arts_And_Culture = arts_And_Culture;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStreamId() {
        return StreamId;
    }

    public void setStreamId(String streamId) {
        StreamId = streamId;
    }

    public String getRequirementsId() {
        return RequirementsId;
    }

    public void setRequirementsId(String requirementsId) {
        RequirementsId = requirementsId;
    }

    public String getMaths() {
        return Maths;
    }

    public void setMaths(String maths) {
        Maths = maths;
    }

    public String getNatural_Science() {
        return Natural_Science;
    }

    public void setNatural_Science(String natural_Science) {
        Natural_Science = natural_Science;
    }

    public String getTechnology() {
        return Technology;
    }

    public void setTechnology(String technology) {
        Technology = technology;
    }

    public String getEMS() {
        return EMS;
    }

    public void setEMS(String EMS) {
        this.EMS = EMS;
    }

    public String getArts_And_Culture() {
        return Arts_And_Culture;
    }

    public void setArts_And_Culture(String arts_And_Culture) {
        Arts_And_Culture = arts_And_Culture;
    }
}
