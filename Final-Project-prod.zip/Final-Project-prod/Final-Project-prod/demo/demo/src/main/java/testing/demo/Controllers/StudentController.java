package testing.demo.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import testing.demo.Services.StudentService;
import testing.demo.model.Student;

import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentController {
@Autowired
    private StudentService studentService;
@PostMapping("/save")
    public Student addStudent(@RequestBody Student student){
    return studentService.saveStudent(student);
    }
    @GetMapping("/get/{id}")

    public ResponseEntity<Student> getStudentById(@PathVariable("id") int id){
    Student student = studentService.getStudentById(id);
    return new ResponseEntity<>(student, HttpStatus.OK) ;
    }
    @GetMapping("/getAll")
    public List<Student> getAllStudents(){
    return studentService.getAllStudents();
    }
    @DeleteMapping("/delete/{id}")
    public String deleteStudentById(@PathVariable int id){
    return studentService.deleteStudentById(id);
    }
    @DeleteMapping("/deleteAll")
    public String deleteAllStudents(){
    return studentService.deleteAllStudent();
    }
    @PutMapping("/update")
    public Student updateStudent(Student student){
        return studentService.updateStudent(student);
    }
}
