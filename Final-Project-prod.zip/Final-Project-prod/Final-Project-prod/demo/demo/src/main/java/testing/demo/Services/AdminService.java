package testing.demo.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import testing.demo.Repository.AdminRepo;
import testing.demo.Repository.UserCredentialRepo;
import testing.demo.model.Admin;
import testing.demo.model.Admin;

import java.util.List;

@Service
public class AdminService {
    @Autowired
    private AdminRepo repo;

    public Admin savePerson(Admin admin){
        return repo.save(admin)  ;
    }

    public Admin findPersonById(int id){
        return repo.findById(id).orElse(null);
    }
    public List<Admin> getAllUser(){
        return  repo.findAll();
    }

    public String deleteById(int id){
        repo.deleteById(id);
        return "A person with  Id  " +id +" is deleted!!";
    }
    public Admin updateAdmin(Admin user){
        Admin existingAdmin=repo.findById(user.getId()).orElse(null);
        existingAdmin.setFull_names(user.getFull_names());
        existingAdmin.setUsername(user.getUsername());
        existingAdmin.setEmail(user.getEmail());
        existingAdmin.setEmployee_no(user.getEmployee_no());
        existingAdmin.setSchool_id(user.getSchool_id());
        existingAdmin.setPhone_Number(user.getPhone_Number());
        existingAdmin.setPassword(user.getPassword());
        return repo.save(existingAdmin);
    }






}
