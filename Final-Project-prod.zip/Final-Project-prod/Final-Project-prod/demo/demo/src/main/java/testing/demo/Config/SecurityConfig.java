package testing.demo.Config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SecurityConfig {

}
