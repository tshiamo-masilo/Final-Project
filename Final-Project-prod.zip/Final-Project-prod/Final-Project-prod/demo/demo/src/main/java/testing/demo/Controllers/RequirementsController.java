package testing.demo.Controllers;

import org.springframework.web.bind.annotation.*;
import testing.demo.Services.RequirementsService;
import testing.demo.model.Requirements;

import java.util.List;

@RestController
@RequestMapping("requirements")
public class RequirementsController {
    private RequirementsService service;

    @PostMapping("/save")
    public Requirements saveRequirements(@RequestBody Requirements requirements){
        return service.saveRequirements(requirements);
    }
    @GetMapping("/get/{id}")
    public Requirements getRequirementsById(@PathVariable int id){
        return service.getRequirementsById(id);
    }
    @GetMapping("/getAll")
    public List<Requirements> getAllRequirements(){
        return service.getAllRequirements();
    }

    @DeleteMapping("/delete/{id}")
    public String deleteRequirementById(@PathVariable int id){
        return service.deleteRequirementsById(id);
    }
    @DeleteMapping("/deleteAll")
    public String deleteAllRequirements(){
        return service.deleteAllRequirements();
    }
    @PutMapping("/update")
    public Requirements updateRequirements(Requirements requirements){
        return service.updateRequirements(requirements);
    }
}
