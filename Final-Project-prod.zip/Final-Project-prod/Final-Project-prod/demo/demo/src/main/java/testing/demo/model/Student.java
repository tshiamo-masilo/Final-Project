package testing.demo.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@Table(name="Students_Details")
@AllArgsConstructor
@NoArgsConstructor
public class Student{
    @Id
    @GeneratedValue()
    @Column()
    private  int id;
    private String School_id;
    private String Student_id;
    private String Class_id;
    private  String grade;
    private String Stream_id;
    private String Name;
    private String surname;
    private String Phone_Number;
    private String Guardian_Name;
    private String Guardian_surname;
    private String Home_Address;
    private String Guardian_Email_Address;
    private String Guardian_Phone_Number;


}
