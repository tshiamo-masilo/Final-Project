package testing.demo.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import testing.demo.Repository.RequirementsRepo;
import testing.demo.model.Requirements;

import java.util.List;
@Service
public class RequirementsService {
    @Autowired
    private RequirementsRepo requirementsRepo;

    public Requirements saveRequirements(Requirements requirements){
        return requirementsRepo.save(requirements);
    }
    public Requirements getRequirementsById(int id){
        return requirementsRepo.findById(id).orElse(null);
    }
    public List<Requirements> getAllRequirements(){
        return requirementsRepo.findAll();
    }
    public String deleteRequirementsById(int id){
        requirementsRepo.deleteById(id);
        return "Record Deleted";
    }
    public String deleteAllRequirements(){
        requirementsRepo.deleteAll();
        return "All Records are deleted";
    }

    public Requirements updateRequirements(Requirements requirements){
        Requirements existingRequirements=requirementsRepo.findById(requirements.getId()).orElse(null);
        existingRequirements.setRequirementsId(requirements.getRequirementsId());
        existingRequirements.setMaths(requirements.getMaths());
        existingRequirements.setNatural_Science(requirements.getNatural_Science());
        existingRequirements.setTechnology(requirements.getTechnology());
        existingRequirements.setEMS(requirements.getEMS());
        existingRequirements.setArts_And_Culture(requirements.getArts_And_Culture());
        return requirementsRepo.save(existingRequirements);
    }
}
